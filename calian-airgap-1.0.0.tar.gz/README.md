# Ansible Collection - thailekha.coremod

Modify ansible's apt module to run "download-only" mode
